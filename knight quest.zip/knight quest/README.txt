Knight Quest
----------------------------------------------------------------------------------------------------------------------------------------------------
knight quest is a text-based adventure set in the nine realms.
you play as a hero sent to defeat the evil dragon, Covnorth, the Rabbit Slayer.

the game was created by 2 noobs who had nothing better to do.

THESE ARE THE CONROLS:
----------------------------------------------------------------COMMANDS----------------------------------------------------------------------------

movement (n, s, w, e)
you can drag yourself through the 9 realms by using your directional know-how. i'm sure you can figure out what the letters stand for using your big brain.

attack 
use the hit command to murderously slaughter all of your buddies. feel free to attempt a pacifist run if you are a christian (we are not) and want to go to heaven
but note that you most certainly will die.

there are no other commands as we are big lazy fools, but then again so are you.



                                                     I HOPE YOU ENJOY SUCKING AT OUR GAME 